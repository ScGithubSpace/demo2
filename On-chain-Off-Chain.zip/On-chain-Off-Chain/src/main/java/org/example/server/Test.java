package org.example.server;


public class Test {

    public static void main(String[] args) {
        PullProjectServer pullProjectServer = new PullProjectServer();
        pullProjectServer.packProject("4b1a956bb8c87e4ebccde37af3e24a1e1ed90d93");
    }

}
