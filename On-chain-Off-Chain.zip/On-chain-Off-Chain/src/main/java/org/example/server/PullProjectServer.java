package org.example.server;

import org.example.bean.Commit;
import org.example.fabric.FabricNetWork;
import org.example.utils.ZipUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class PullProjectServer {

    public void packProject(String hash){
        FabricNetWork fabricNetWork = new FabricNetWork();
        Commit commit = fabricNetWork.queryProjectInfoByHash(hash);
        if (commit != null && !"".equals(commit.getProjectDir())){
            compressFile(commit.getProjectDir());
        }
    }

    public static void compressFile(String sourceFileDir){
        try {
            File targetFile = new File(sourceFileDir + ".zip");
            OutputStream out = new FileOutputStream(targetFile);
            ZipUtils.toZip(sourceFileDir, out, true);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
