package com.shuc.dataupload;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatauploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
