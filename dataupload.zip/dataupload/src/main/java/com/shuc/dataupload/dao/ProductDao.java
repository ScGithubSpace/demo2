package com.shuc.dataupload.dao;

import com.shuc.dataupload.bean.Product;

import java.util.List;

public interface ProductDao {

    Product getProductById(Integer id);

    List<Product> getAllProduct();

    Integer addProduct(Product product);

    void updateProduct(Product product);

}
