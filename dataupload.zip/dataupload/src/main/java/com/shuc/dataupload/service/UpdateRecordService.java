package com.shuc.dataupload.service;

import com.shuc.dataupload.bean.UpdateRecord;
import com.shuc.dataupload.dao.UpdateRecordDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UpdateRecordService {

    @Autowired
    UpdateRecordDao updateRecordDao;

    public List<UpdateRecord> getUpdateRecordByProductId(Integer id){
        return updateRecordDao.getUpdateRecordByProductId(id);
    }

    public void addUpdateRecord(UpdateRecord record){
        updateRecordDao.addUpdateRecord(record);
    }


}
