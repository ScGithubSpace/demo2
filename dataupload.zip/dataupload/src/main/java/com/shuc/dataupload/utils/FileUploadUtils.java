package com.shuc.dataupload.utils;

import cn.hutool.core.util.IdUtil;

//文件上传下载工具类
public class FileUploadUtils {


    //根据旧文件名生成新文件名
    public static String createNewFileName(String oldName) {
        String stuff = oldName.substring(oldName.lastIndexOf("."));
        return IdUtil.simpleUUID().toUpperCase()+stuff;
    }
}
