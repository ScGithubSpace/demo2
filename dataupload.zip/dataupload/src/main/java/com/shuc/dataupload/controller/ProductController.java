package com.shuc.dataupload.controller;

import com.shuc.dataupload.bean.Product;
import com.shuc.dataupload.bean.UpdateRecord;
import com.shuc.dataupload.common.TableData;
import com.shuc.dataupload.service.ProductServiceImpl;
import com.shuc.dataupload.service.UpdateRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
public class ProductController {

    @Autowired
    ProductServiceImpl productService;

    @Autowired
    UpdateRecordService updateRecordService;

    @GetMapping("/product/{id}")
    @ResponseBody
    public Product getProductById(@PathVariable("id") Integer id){
        return productService.getProductById(id);
    }

    @GetMapping("/product")
    @ResponseBody
    public TableData getAllProduct(){
        return productService.getAllProduct();
    }


    @PostMapping("/product")
    @ResponseBody
    public Integer addProduct(Product product){
        productService.addProduct(product);
        return product.getId();
    }

    @PostMapping("/updateProduct")
    @ResponseBody
    public Integer updateProduct(Product product){
        productService.updateProduct(product);
        return 1;
    }

    @RequestMapping("/test")
    @ResponseBody
    public void test(UpdateRecord record){
        updateRecordService.addUpdateRecord(record);
    }


}
