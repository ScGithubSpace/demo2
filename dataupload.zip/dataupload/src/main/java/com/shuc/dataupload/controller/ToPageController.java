package com.shuc.dataupload.controller;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class ToPageController {

    @RequestMapping("/toProductListPage")
    public String toProductListPage(){
        return "productList";
    }

    @RequestMapping("/toUpdateProductPage")
    public String toUpdateProduct(Integer id, HttpServletRequest request){
        request.setAttribute("id", id);
        return "updateProduct";
    }


}
