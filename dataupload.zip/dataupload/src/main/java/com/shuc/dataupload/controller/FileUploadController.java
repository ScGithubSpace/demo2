package com.shuc.dataupload.controller;


import com.shuc.dataupload.service.FileStorageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;


@Controller
public class FileUploadController {


    private final FileStorageService service;

    public FileUploadController(FileStorageService service){
        this.service = service;
    }


    @PostMapping("/uploadFile")
    @ResponseBody
    public Map<String,Object> uploadFile(@RequestParam("file") MultipartFile file){
       return service.storeFile(file);
    }



    @ResponseBody
    @GetMapping("/downloadFile")
    public ResponseEntity<Object> downloadFile(String path){
        Resource resource = service.loadFile(path);
        String[] strArr = path.split("\\.");
        String fileNamePrefix = strArr[0];
        String fileNameSuffix = strArr[1];
        String finalFileName = null;
        try {
            //对文件名前缀进行编码
            finalFileName = URLEncoder.encode(fileNamePrefix,"UTF-8")+"."+fileNameSuffix;
        }catch (UnsupportedEncodingException e){
            e.printStackTrace();
        }

        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + finalFileName + "\"").body(resource);

    }


}
