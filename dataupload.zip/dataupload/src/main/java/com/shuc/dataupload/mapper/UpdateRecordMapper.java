package com.shuc.dataupload.mapper;

import com.shuc.dataupload.bean.UpdateRecord;

import java.util.List;

public interface UpdateRecordMapper {

    List<UpdateRecord> getUpdateRecordByProductId(Integer id);

    void addUpdateRecord(UpdateRecord record);

}
