package com.shuc.dataupload.dao;

import com.shuc.dataupload.bean.Product;
import com.shuc.dataupload.mapper.ProductMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductDaoImpl implements ProductDao{

    @Autowired
    ProductMapper productMapper;

    @Override
    public Product getProductById(Integer id) {
        return productMapper.getProductById(id);
    }

    @Override
    public List<Product> getAllProduct() {
        return productMapper.getAllProduct();
    }

    @Override
    public Integer addProduct(Product product) {
        productMapper.addProduct(product);
        return product.getId();
    }

    @Override
    public void updateProduct(Product product) {
        productMapper.updateProduct(product);
    }
}
