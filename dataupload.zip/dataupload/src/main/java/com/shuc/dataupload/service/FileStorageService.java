package com.shuc.dataupload.service;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.unit.DataUnit;
import com.shuc.dataupload.config.FileStorageProperties;
import com.shuc.dataupload.exception.FileStorageException;
import com.shuc.dataupload.utils.FileUploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class FileStorageService {

    @Autowired
    FileStorageProperties fileStorageProperties;


    public Map<String,Object> storeFile(MultipartFile mf){
        //1,得到文件名
        String oldName = mf.getOriginalFilename();
        //2,根据文件名生成新的文件名
        String newName = FileUploadUtils.createNewFileName(oldName);
        //3,得到当前日期的字符串
        String dirName = DateUtil.format(new Date(),"yyyy-MM-dd");
        //4,构造文件夹
        File dirFile = new File(fileStorageProperties.getUploadDir(),dirName);
        //5,判断文件是否存在
        if(!dirFile.exists()){
            dirFile.mkdirs();//创建文件夹
        }
        //5,构造文件对象
        File file = new File(dirFile,newName);
        try {
            mf.transferTo(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Map<String,Object> map = new HashMap<>();
        map.put("path",dirName + "/" + newName);
        return map;
    }

    public Resource  loadFile(String path){
        //构造文件对象
        Path fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir());
        try {
            Path filePath = fileStorageLocation.resolve(path).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()){
                return resource;
            }else {
                throw new FileStorageException("File not found" + path);
            }

        }catch (Exception e){
            throw new FileStorageException("File not found" + path);
        }
    }

}
