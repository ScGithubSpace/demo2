package com.shuc.dataupload.service;

import com.shuc.dataupload.bean.Product;
import com.shuc.dataupload.common.TableData;
import com.shuc.dataupload.dao.ProductDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    ProductDaoImpl productDao;

    @Override
    public Product getProductById(Integer id) {
        return productDao.getProductById(id);
    }

    @Override
    public TableData getAllProduct() {
        List<Product> allProduct = productDao.getAllProduct();
        TableData tableData = new TableData(0,"ji",allProduct.size(),allProduct);
        return tableData;
    }

    @Override
    public Integer addProduct(Product product) {
        productDao.addProduct(product);
        return product.getId();
    }

    @Override
    public void updateProduct(Product product) {
        productDao.updateProduct(product);
    }
}
