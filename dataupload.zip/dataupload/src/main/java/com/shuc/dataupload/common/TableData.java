package com.shuc.dataupload.common;

import com.shuc.dataupload.bean.Product;

import java.util.List;

public class TableData {

    private Integer code;

    private String msg;

    private Integer count;

    private List<Product> data;

    public TableData(Integer code, String msg, Integer count, List<Product> data) {
        this.code = code;
        this.msg = msg;
        this.count = count;
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<Product> getData() {
        return data;
    }

    public void setData(List<Product> data) {
        this.data = data;
    }
}
