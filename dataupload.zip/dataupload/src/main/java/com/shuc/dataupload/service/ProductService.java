package com.shuc.dataupload.service;

import com.shuc.dataupload.bean.Product;
import com.shuc.dataupload.common.TableData;

import java.util.List;

public interface ProductService {

    Product getProductById(Integer id);

    TableData getAllProduct();

    Integer addProduct(Product product);

    void updateProduct(Product product);

}
