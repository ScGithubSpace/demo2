package com.shuc.dataupload.dao;

import com.shuc.dataupload.bean.UpdateRecord;
import com.shuc.dataupload.mapper.UpdateRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UpdateRecordDao {

    @Autowired
    UpdateRecordMapper mapper;

    public List<UpdateRecord> getUpdateRecordByProductId(Integer id){
        return mapper.getUpdateRecordByProductId(id);
    }

    public void addUpdateRecord(UpdateRecord record){
        mapper.addUpdateRecord(record);
    }

}
