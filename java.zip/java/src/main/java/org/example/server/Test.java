package org.example.server;

import org.example.bean.Commit;

public class Test {

//    public static void main(String[] args) {
//        String s = ".git/objects/la/fjalgjlkadsjglkasjdlkgf\n"
//                +"tree dasgjlkdasjfaslkdj\n"
//                +"parent fasfgasdgasdfasd\n"
//                + "author fasdsdfdasfasdfa\n"
//                + "committer vsfgsfdgsafdgasfd\n\n"
//                + "commit03";
//        String[] strings = s.split("\n");
//        String[] hashArr = strings[0].split("/");
//        String hash = hashArr[2] + hashArr[3];
//        String tree = strings[1].split(" ")[1];
//        String parent = strings[2].split(" ")[1];
//        String author = strings[3].split(" ")[1];
//        String committer = strings[4].split(" ")[1];
//        String msg = strings[6];
//        Commit commit = new Commit(hash,tree,parent,author,committer,msg);
//        System.out.println(commit);
//    }



}
