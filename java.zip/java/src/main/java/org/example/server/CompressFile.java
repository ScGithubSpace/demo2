package org.example.server;

import org.example.utils.ZipUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class CompressFile {

    public static void main(String[] args) {
        try {
            File targetFile = new File("/home/json/git-test/test01.zip");
            OutputStream out = new FileOutputStream(targetFile);
            ZipUtils.toZip("/home/json/git-test/test01", out, true);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
